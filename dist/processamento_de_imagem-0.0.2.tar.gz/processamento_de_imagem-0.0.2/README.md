# Processamento de Imagem

O pacotede de processamento de imagem e usado para:<br />
	- Transferencia de histograma.<br />
	- Diferenciacao de imagem.<br />
	- Redimencionamento de imagem.<br />
	- Plot de imagem.<br />
	- Plot de histograma.<br />
	- Plot de resultados.<br />
	- Salvar imagem.<br />
	- Carregar imagem.<br />

## Instalacao

Use o pacote de instalacao [pip](https://pip.pypa.io/en/stable/) para a instalacao, por exemplo:

```bash
pip install processamento_de_imagem
```

## Autor
Jhonathan Alves

## Licenca
[MIT](https://choosealicense.com/licenses/mit/)